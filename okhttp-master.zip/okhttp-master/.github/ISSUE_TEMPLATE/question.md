---
name: Question
about: Use Stack Overflow instead
title: "\U0001F649"
labels: ''
assignees: ''

---

🛑 𝙎𝙏𝙊𝙋

This issue tracker is not the place for questions!

If you want to ask how to do something, or to understand why something isn't working the way you expect it to, use Stack Overflow. https://stackoverflow.com/questions/tagged/okhttp

We close all questions without reading them.
