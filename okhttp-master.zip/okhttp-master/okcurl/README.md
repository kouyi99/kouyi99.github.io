OkCurl
======

_A curl for the next-generation web._

OkCurl is an OkHttp-backed curl clone which allows you to test OkHttp's HTTP engine (including
HTTP/2) against web servers.
