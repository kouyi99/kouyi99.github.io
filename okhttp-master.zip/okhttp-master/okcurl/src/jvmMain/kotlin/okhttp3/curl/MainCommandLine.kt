package okhttp3.curl

import kotlin.system.exitProcess

fun main(args: Array<String>) {
  Main().main(args)
  exitProcess(0)
}
